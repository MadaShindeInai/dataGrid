const arrOfTitles = [
  'First Name',
  'Last Name',
  'City',
  'Driver',
  'Email',
  'Number',
  'KeyWord'
];
export default arrOfTitles;