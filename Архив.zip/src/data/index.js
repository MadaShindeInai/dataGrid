import data from './data';
import arrOfTitles from './titles';

export {
  data,
  arrOfTitles
};