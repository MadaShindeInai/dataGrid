import Controlls from './Controlls';

export default Controlls;