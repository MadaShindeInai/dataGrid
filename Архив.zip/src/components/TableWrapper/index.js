import TableWrapper from './TableWrapper';

export default TableWrapper;