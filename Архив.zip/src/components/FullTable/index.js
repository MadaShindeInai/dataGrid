import FullTable from './FullTable';

export default FullTable